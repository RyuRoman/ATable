<section class="ftco-section ftco-no-pt ftco-no-pb py-5 bg-light">
  <div class="container py-4">
    <div class="row d-flex justify-content-center py-5">
      <div class="col-md-6">
        <h2 style="font-size: 22px;" class="mb-0">Inscrivez vous sur notre Newsletter</h2>
        <span>Recevez des e-mails d'offres intéressantes A'Table</span>
      </div>
      <div class="col-md-6 d-flex align-items-center">
        <form action="#" class="subscribe-form">
          <div class="form-group d-flex">
            <input type="text" class="form-control" placeholder="Entrer votre adresse mail">
            <input type="submit" value="S'inscrire" class="submit px-3">
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
