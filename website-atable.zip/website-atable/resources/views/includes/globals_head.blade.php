<script type="text/javascript">
    const $apiUrl = '{{env("API_URL")}}';
    const $webUrl = '{{env("WEB_URL")}}';
</script>
