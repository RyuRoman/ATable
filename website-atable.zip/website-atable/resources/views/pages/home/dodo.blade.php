@extends('layouts.home')
@section('content')
<script src="js/dodo.js"></script>
<script src="https://www.paypal.com/sdk/js?client-id=AStUT8j4Dzwpy1funHhJAvSwzpPmNa6iCxTeP-oz5E3mIKcPq95coLAVjcn08VVCy7gpwv3yNNdoadaE&currency=EUR"></script>
<center>
<div id="paypal-button-container">
  <!-- <p><a href="/checkout" class="btn btn-primary py-3 px-4">Proceed to Checkout</a></p> -->
</div>
</center>

@Stop
