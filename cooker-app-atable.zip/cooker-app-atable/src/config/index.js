const config = {
  /*
    theme: 'jade' | 'redOrange' | 'blueberry'
   */
  theme: "jade"
};

export default config;
