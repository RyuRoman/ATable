@extends('layouts.auth')
@section('content')
<div class="card-body">
  <a href="/landing">
      <input type="button" value="Cooker" class="btn float-left login_btn">
      <input type="button" value="Customer" class="btn float-right login_btn">
      <a/>
</div>
@stop
