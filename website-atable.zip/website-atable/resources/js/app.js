/**
 * Js packages included
 */

require('./bootstrap');
const axios = require('axios');
