$(document).ready(function(){var c=window.localStorage.getItem("command_qty");null!=c?$("#cart_icon").replaceWith(c):$("#cart_icon").replaceWith("0")});
