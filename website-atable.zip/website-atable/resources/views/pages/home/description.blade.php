@extends('layouts.home')
@section('content')

  <!-- <div class="col-md-6 order-md-last d-flex"> -->
    <form action="#" class="bg-white p-5 contact-form">
      <center class="form-group">
        <textarea class="" name="" id="descritpion" cols="30" rows="7" class="form-control" placeholder="Description"></textarea>
      </center>
      <center class="form-group">
        <input id="desc-btn" value="Modifier" class="btn btn-primary py-3 px-5">
      </center>
    </form>
    <style>
</style>


  </div>

<!-- </div> -->

@Stop
